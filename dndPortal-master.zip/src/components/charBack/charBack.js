import './charBack.css'

function CharBack(){
    return(
        <div>
            Char Background Base
        </div>
    )
}

export default CharBack