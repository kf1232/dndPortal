import './banner.css'

export default function Banner(props) {
    //const [standard, renderStandard] = useState(true)
	//const toggleStandard = () => {renderStandard((prev) => !prev)}
	
	//const [pointbuy, renderPointbuy] = useState(true)
	//const togglePointbuy = () => {renderPointbuy((prev) => !prev)}

	//const [custom, renderCustom] = useState(true)
	//const toggleCustom = () => {renderCustom((prev) => !prev)}

    return (
        <div>

        </div>
    )
}