import './charEquip.css'

function CharEquip(){
    return(
        <div>
            Char Equipment Base
        </div>
    )
}

export default CharEquip